#!/bin/bash
set -euo pipefail
SRC="${1:-/tmp/lex-sepidz-bundle}"
G=/usr/local/lib/claude-server
H=$G/cursor-hooks
mkdir -p "$H" "$G/skills/laptop-exec" "$G/cursor-rules"
install -m 0755 "$SRC/laptop-exec.sh" /usr/local/bin/laptop-exec
install -m 0755 "$SRC/laptop-exec.sh" "$G/laptop-exec.sh"
install -m 0755 "$SRC/laptop-exec-setup.sh" /usr/local/bin/laptop-exec-setup
install -m 0755 "$SRC/laptop-exec-setup.sh" "$G/laptop-exec-setup.sh"
for f in laptop-exec-guard.sh laptop-exec-guard-wrap.sh laptop-exec-session.sh laptop-exec-shell-scan.py; do
  install -m 0755 "$SRC/cursor-hooks/$f" "$H/$f"
done
install -m 0644 "$SRC/cursor-hooks/hooks-user.json" "$H/hooks-user.json"
install -m 0644 "$SRC/cursor-hooks/hooks-project.json" "$H/hooks-project.json"
install -m 0644 "$SRC/skills/laptop-exec/SKILL.md" "$G/skills/laptop-exec/SKILL.md"
install -m 0644 "$SRC/cursor-rules/laptop-exec.mdc" "$G/cursor-rules/laptop-exec.mdc"

MATCH="Grep|Glob|Read|Write|Edit|EditNotebook|StrReplace|Delete|Task"
ok=0; bad=0
while IFS=: read -r u _ uid _ _ home _; do
  [ "$uid" -ge 1000 ] 2>/dev/null || continue
  [ "$u" = nobody ] && continue
  [ -d "$home" ] || continue
  mkdir -p "$home/.local/bin" "$home/.cursor/hooks" "$home/.cursor/rules" "$home/.cursor/skills/laptop-exec"
  install -m 0755 /usr/local/bin/laptop-exec "$home/.local/bin/laptop-exec"
  for f in laptop-exec-guard.sh laptop-exec-guard-wrap.sh laptop-exec-session.sh laptop-exec-shell-scan.py; do
    install -m 0755 "$H/$f" "$home/.cursor/hooks/$f"
  done
  install -m 0644 "$G/skills/laptop-exec/SKILL.md" "$home/.cursor/skills/laptop-exec/SKILL.md"
  install -m 0644 "$G/cursor-rules/laptop-exec.mdc" "$home/.cursor/rules/laptop-exec.mdc"
  rm -f "$home/.cursor/hooks/.guard-syntax-ok"
  python3 - "$home" "$MATCH" <<'PY'
import json,sys
from pathlib import Path
home,match=sys.argv[1],sys.argv[2]
p=Path(home)/".cursor"/"hooks.json"
d={"version":1,"hooks":{
  "sessionStart":[{"command":f"{home}/.cursor/hooks/laptop-exec-session.sh"}],
  "beforeShellExecution":[{"command":f"{home}/.cursor/hooks/laptop-exec-guard-wrap.sh"}],
  "preToolUse":[{"command":f"{home}/.cursor/hooks/laptop-exec-guard-wrap.sh","matcher":match}],
}}
p.write_text(json.dumps(d,indent=2)+"\n")
empty={"version":1,"hooks":{}}
mp=Path(home)/"mounts"
if mp.is_dir():
  for hp in mp.glob("*/.cursor/hooks.json"):
    hp.write_text(json.dumps(empty,indent=2)+"\n")
PY
  chown -R "$u:$u" "$home/.local/bin/laptop-exec" "$home/.cursor" 2>/dev/null || true
  if grep -q 'guard-wrap' "$home/.cursor/hooks.json" && bash -n "$home/.cursor/hooks/laptop-exec-guard.sh"; then
    m=$(python3 -c "import json;print(json.load(open('$home/.cursor/hooks.json'))['hooks']['preToolUse'][0]['matcher'])")
    if echo "$m" | grep -q Shell; then echo "SHELL_IN_PRE $u"; bad=$((bad+1)); continue; fi
    echo "OK $u"; ok=$((ok+1))
  else
    echo "BAD $u"; bad=$((bad+1))
  fi
done < <(getent passwd)
echo "SEPIDZ_RESULT ok=$ok bad=$bad host=$(hostname)"
