#!/usr/bin/env bash
set -euo pipefail

SERVER_IP="192.168.210.240"
ALIAS="claude-server"
CFG_DIR="$HOME/.config/claude-connect"
CFG_FILE="$CFG_DIR/connect.conf"
CM='$HOME/.local/bin/claude-mount'
SSH_DIR="$HOME/.ssh"
KEY="$SSH_DIR/id_ed25519"
LAPTOP_KEY="$SSH_DIR/claude_laptop"
PORT=0
REMOTE_USER=""
LAPTOP_USER=""

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
die()      { echo "[FATAL] $*" >&2; exit 1; }
warn()     { echo "[WARN]  $*" >&2; }
step()     { echo; echo ">>> $*"; }
step_ok()  { echo "    [OK] $*"; }
step_fail(){ echo "    [FAIL] $*" >&2; }

sshx() {
    ssh -n \
        -o ClearAllForwardings=yes \
        -o BatchMode=yes \
        -o ConnectTimeout=10 \
        -o ServerAliveInterval=5 \
        -o ServerAliveCountMax=3 \
        "$ALIAS" "$1"
}

tunnel_up() {
    timeout 3 bash -c "exec 3<>/dev/tcp/127.0.0.1/$PORT" 2>/dev/null
}

# ---------------------------------------------------------------------------
# Config load/save
# ---------------------------------------------------------------------------
load_config() {
    if [ -f "$CFG_FILE" ]; then
        while IFS='=' read -r k v; do
            case "$k" in
                REMOTE_USER) REMOTE_USER="$v" ;;
                LAPTOP_USER) LAPTOP_USER="$v" ;;
            esac
        done < "$CFG_FILE"
    fi
}

save_config() {
    mkdir -p "$CFG_DIR"
    printf 'REMOTE_USER=%s\nLAPTOP_USER=%s\n' "$REMOTE_USER" "$LAPTOP_USER" > "$CFG_FILE"
}

# ---------------------------------------------------------------------------
# SSH config helpers
# ---------------------------------------------------------------------------
remove_ssh_host_block() {
    local host="$1"
    local cfg="$SSH_DIR/config"
    [ -f "$cfg" ] || return 0
    local tmp; tmp=$(mktemp)
    local skip=0
    while IFS= read -r line; do
        if [[ "$line" =~ ^[[:space:]]*Host[[:space:]]+$host[[:space:]]*$ ]]; then
            skip=1
        elif [[ $skip -eq 1 && "$line" =~ ^[[:space:]]*Host[[:space:]]+ ]]; then
            skip=0
        fi
        [ $skip -eq 0 ] && echo "$line" >> "$tmp"
    done < "$cfg"
    mv "$tmp" "$cfg"
}

write_ssh_block() {
    local extra="${1:-}"
    remove_ssh_host_block "$ALIAS"
    cat >> "$SSH_DIR/config" <<EOF

Host $ALIAS
    HostName $SERVER_IP
    User $REMOTE_USER
    IdentityFile ~/.ssh/id_ed25519
    StrictHostKeyChecking no
$extra
EOF
}

# ---------------------------------------------------------------------------
# Mount list helpers
# ---------------------------------------------------------------------------
load_mounts() {
    sshx "$CM list 2>/dev/null" 2>/dev/null || true
}

show_mounts() {
    local raw="$1"
    if [ -z "$raw" ]; then
        echo "  (no projects configured)"
        return
    fi
    local i=1
    while IFS='|' read -r id label rpath lpath; do
        printf "  %2d.  %-20s  %s\n" "$i" "$label" "$lpath"
        i=$((i + 1))
    done <<< "$raw"
}

pick_mount() {
    local raw="$1"
    local prompt="${2:-Select project number}"
    printf "%s: " "$prompt"
    read -r n
    local i=1
    while IFS='|' read -r id label rpath lpath; do
        if [ "$i" -eq "$n" ] 2>/dev/null; then
            echo "$id|$label|$rpath|$lpath"
            return 0
        fi
        i=$((i + 1))
    done <<< "$raw"
    return 1
}

do_add() {
    printf "Local folder path (on this laptop): "
    read -r lpath
    printf "Project name/label: "
    read -r label
    [ -z "$label" ] && label="$(basename "$lpath")"
    local id; id="$(echo "$label" | tr -cs 'a-zA-Z0-9_-' '_')"
    local rpath="$lpath"
    local out; out=$(sshx "$CM add '$id' '$label' '$rpath' '$lpath' 2>&1") && \
        step_ok "Project '$label' added (id=$id)" || \
        step_fail "Add failed: $out"
}

# ---------------------------------------------------------------------------
# Load config
# ---------------------------------------------------------------------------
load_config

# ---------------------------------------------------------------------------
# Step 1 - Check SSH client
# ---------------------------------------------------------------------------
step "Checking SSH client"
command -v ssh >/dev/null 2>&1 || die "ssh not found in PATH"
step_ok "ssh found: $(command -v ssh)"

# ---------------------------------------------------------------------------
# Step 2 - Check sshd running on laptop
# ---------------------------------------------------------------------------
step "Checking local sshd"
if pgrep -x sshd >/dev/null 2>&1; then
    step_ok "sshd is running"
else
    warn "sshd does not appear to be running locally."
    warn "The reverse tunnel needs sshd on this laptop."
    warn "On macOS: sudo systemsetup -setremotelogin on"
fi

# ---------------------------------------------------------------------------
# Step 3 - Create server SSH key
# ---------------------------------------------------------------------------
step "Checking server SSH key"
mkdir -p "$SSH_DIR"
chmod 700 "$SSH_DIR"
if [ ! -f "$KEY" ]; then
    step "Generating SSH key pair"
    ssh-keygen -t ed25519 -f "$KEY" -N "" -q
    step_ok "Key created: $KEY"
else
    step_ok "Key already exists: $KEY"
fi

# ---------------------------------------------------------------------------
# Step 4 - Write ~/.ssh/config block
# ---------------------------------------------------------------------------
step "Writing SSH config for $ALIAS"
touch "$SSH_DIR/config"
chmod 600 "$SSH_DIR/config"
write_ssh_block
step_ok "SSH config updated"

# ---------------------------------------------------------------------------
# Step 5 - Connect (install key if needed)
# ---------------------------------------------------------------------------
step "Testing connection to $ALIAS"
if [ -z "$REMOTE_USER" ]; then
    printf "Remote username on server: "
    read -r REMOTE_USER
    REMOTE_USER="$(echo "$REMOTE_USER" | tr -d '[:space:]')"
    write_ssh_block
    save_config
fi

if ! sshx "echo ok" 2>/dev/null | grep -q ok; then
    warn "Key not installed yet - attempting ssh-copy-id"
    if command -v ssh-copy-id >/dev/null 2>&1; then
        ssh-copy-id -i "$KEY.pub" "$REMOTE_USER@$SERVER_IP" || true
    else
        local pub; pub=$(cat "$KEY.pub")
        ssh -o StrictHostKeyChecking=no -o BatchMode=no \
            "$REMOTE_USER@$SERVER_IP" \
            "mkdir -p ~/.ssh && chmod 700 ~/.ssh && echo '$pub' >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys" || true
    fi

    if ! sshx "echo ok" 2>/dev/null | grep -q ok; then
        echo "    Connection still failing. Username wrong?" >&2
        printf "    Enter new username (or Enter to exit): "
        read -r new_user
        [ -z "$new_user" ] && die "Cannot connect to server."
        REMOTE_USER="$(echo "$new_user" | tr -d '[:space:]')"
        write_ssh_block
        save_config
        sshx "echo ok" 2>/dev/null | grep -q ok || die "Still cannot connect as $REMOTE_USER."
    fi
fi
step_ok "Connected as $REMOTE_USER"

# ---------------------------------------------------------------------------
# Step 6 - Tunnel setup
# ---------------------------------------------------------------------------
step "Setting up reverse tunnel key"
uid_raw=$(sshx "id -u" 2>/dev/null | tr -d '[:space:]')
PORT=$((20000 + uid_raw))

if [ ! -f "$LAPTOP_KEY" ]; then
    step "Generating tunnel key pair (claude_laptop)"
    ssh-keygen -t ed25519 -f "$LAPTOP_KEY" -N "" -q
    step_ok "Tunnel key created: $LAPTOP_KEY"
else
    step_ok "Tunnel key already exists: $LAPTOP_KEY"
fi

[ -z "$LAPTOP_USER" ] && LAPTOP_USER="$(whoami)"

laptop_pub=$(cat "$LAPTOP_KEY.pub")
auth_keys="$SSH_DIR/authorized_keys"
touch "$auth_keys"
chmod 600 "$auth_keys"
if ! grep -qF "$laptop_pub" "$auth_keys" 2>/dev/null; then
    echo "$laptop_pub" >> "$auth_keys"
    step_ok "Tunnel public key added to $auth_keys"
else
    step_ok "Tunnel public key already in $auth_keys"
fi

write_ssh_block "    RemoteForward $PORT localhost:22"

# Write ~/.claude-connect.conf
cat > "$HOME/.claude-connect.conf" <<EOF
LAPTOP_USER=$LAPTOP_USER
TUNNEL_PORT=$PORT
EOF
step_ok "Tunnel configured: port $PORT, laptop user $LAPTOP_USER"
save_config

# ---------------------------------------------------------------------------
# Step 7 - Push latest claude-mount.sh if available
# ---------------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
mount_script="$SCRIPT_DIR/../../server/claude-mount.sh"
if [ -f "$mount_script" ]; then
    step "Pushing claude-mount.sh to server"
    if scp -o StrictHostKeyChecking=no -o BatchMode=yes \
            "$mount_script" "${ALIAS}:~/.local/bin/claude-mount" 2>/dev/null; then
        sshx "chmod +x ~/.local/bin/claude-mount; grep -qxF 'export PATH=\$HOME/.local/bin:\$PATH' ~/.bashrc || echo 'export PATH=\$HOME/.local/bin:\$PATH' >> ~/.bashrc" >/dev/null 2>&1 || true
        step_ok "claude-mount pushed and PATH updated"
    else
        warn "scp of claude-mount.sh failed"
    fi
fi

# ---------------------------------------------------------------------------
# Main menu loop
# ---------------------------------------------------------------------------
while true; do
    echo
    echo "=== Claude Server Projects ==="
    mounts_raw=$(load_mounts)
    show_mounts "$mounts_raw"
    echo
    echo "  a add   e edit   d delete   c config   q quit"
    echo
    printf "Select project # or action: "
    read -r choice

    case "$choice" in
        q) exit 0 ;;

        a)
            do_add
            ;;

        e)
            sel=$(pick_mount "$mounts_raw" "Edit project #") || { warn "Invalid selection"; continue; }
            IFS='|' read -r m_id m_label m_rpath m_lpath <<< "$sel"
            printf "New label [%s]: " "$m_label"; read -r v; [ -n "$v" ] && m_label="$v"
            printf "New remote path [%s]: " "$m_rpath"; read -r v; [ -n "$v" ] && m_rpath="$v"
            printf "New local path [%s]: " "$m_lpath"; read -r v; [ -n "$v" ] && m_lpath="$v"
            sshx "$CM rm '$m_id' 2>/dev/null; $CM add '$m_id' '$m_label' '$m_rpath' '$m_lpath'" >/dev/null 2>&1 || true
            step_ok "Project updated"
            ;;

        d)
            sel=$(pick_mount "$mounts_raw" "Delete project #") || { warn "Invalid selection"; continue; }
            IFS='|' read -r m_id m_label _ _ <<< "$sel"
            printf "Delete '%s'? [y/N]: " "$m_label"; read -r confirm
            if [[ "$confirm" =~ ^[yY]$ ]]; then
                sshx "$CM rm '$m_id' 2>&1" >/dev/null 2>&1 || true
                step_ok "Deleted '$m_label'"
            fi
            ;;

        c)
            printf "New remote username [%s]: " "$REMOTE_USER"; read -r v
            if [ -n "$v" ]; then
                REMOTE_USER="$(echo "$v" | tr -d '[:space:]')"
                write_ssh_block "    RemoteForward $PORT localhost:22"
                save_config
                step_ok "Username updated to $REMOTE_USER"
            fi
            ;;

        *)
            n="$choice"
            if ! [[ "$n" =~ ^[0-9]+$ ]]; then warn "Unknown input"; continue; fi

            mount_count=$(echo "$mounts_raw" | grep -c '|' 2>/dev/null || echo 0)
            if [ "$n" -lt 1 ] || [ "$n" -gt "$mount_count" ] 2>/dev/null; then
                warn "Out of range"
                continue
            fi

            sel=$(pick_mount "$mounts_raw" "x" <<< "$n") || { warn "Invalid selection"; continue; }
            IFS='|' read -r m_id m_label m_rpath m_lpath <<< "$sel"

            step "Mounting '$m_label'"

            # 1. Check VSCode
            command -v code >/dev/null 2>&1 || die "VSCode 'code' command not found in PATH."

            # 2. Kill stale tunnel processes
            pkill -f "ssh.*-R ${PORT}:localhost:22" 2>/dev/null || true

            # 3. Start background tunnel
            ssh -fN \
                -o ExitOnForwardFailure=yes \
                -o ServerAliveInterval=15 \
                -o ServerAliveCountMax=3 \
                -R "${PORT}:localhost:22" \
                "$ALIAS" &
            bg_tunnel_pid=$!

            # 4. Wait for tunnel
            tunnel_ready=0
            for _ in 1 2 3 4 5 6; do
                sleep 2
                if tunnel_up; then tunnel_ready=1; break; fi
            done

            if [ $tunnel_ready -eq 0 ]; then
                step_fail "Reverse tunnel did not come up on port $PORT"
                kill "$bg_tunnel_pid" 2>/dev/null || true
                exit 1
            fi

            # 5. Mount via claude-mount
            mount_out=$(sshx "$CM up '$m_id' 2>&1")
            mount_failed=0
            if echo "$mount_out" | grep -qiE "error|fail|No such|not found|cannot|refused" && \
               ! echo "$mount_out" | grep -qi "already mounted"; then
                mount_failed=1
            fi

            if [ $mount_failed -eq 1 ]; then
                step_fail "Mount failed for '$m_id'"
                echo
                echo "  Output: $mount_out"
                echo
                echo "  Hints:"
                echo "    - Is sshd running on this laptop?"
                echo "    - Is port $PORT reachable?"
                echo "    - Test tunnel: ssh -v -p $PORT -i ~/.ssh/claude_laptop ${LAPTOP_USER}@localhost 'echo ok'"
                echo "    - Is ~/.ssh/claude_laptop.pub in your authorized_keys?"
                echo
                exit 1
            fi

            # 6. Kill tunnel, open VSCode
            kill "$bg_tunnel_pid" 2>/dev/null || true

            step_ok "Mount successful"
            folder_uri="vscode-remote://ssh-remote+${ALIAS}${m_lpath}"
            code --folder-uri "$folder_uri"
            step_ok "VSCode opened: $m_lpath"

            # Mount remaining projects in background
            sshx "($CM up >/dev/null 2>&1 &); true" >/dev/null 2>&1 || true
            ;;
    esac
done
